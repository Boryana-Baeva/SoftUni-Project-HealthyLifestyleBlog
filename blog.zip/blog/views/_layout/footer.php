
    <footer>
        (c) Blog System, 2016
    </footer>

    <?php require_once("fill-posted-fields.php"); ?>

    <?php require_once("show-validation-errors.php"); ?>

</body>

</html>
